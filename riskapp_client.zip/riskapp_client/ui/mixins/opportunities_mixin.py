"""MainWindow mixin for the Opportunities tab.

Filtering, table rendering, editor behavior, and CSV export for opportunities.
"""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt  # pylint: disable=no-name-in-module
from PySide6.QtWidgets import QFileDialog, QMessageBox  # pylint: disable=no-name-in-module

from riskapp_client.domain.models import Opportunity
from riskapp_client.services import export_csv, filters
from riskapp_client.ui.mixins.scored_entities_ui import (
    date_bounds,
    form_values_for_entity,
    populate_scored_table,
    score_bounds,
)
from riskapp_client.utils.normalize import norm_optional_text_fields

class OpportunitiesMixin:
    """MainWindow mixin: OpportunitiesMixin"""

    def _mark_opp_editor_dirty(self, *args) -> None:
        self._opp_editor_dirty = True

    def _commit_opp_editor_changes(self, *, refresh: bool, select_id: str | None = None) -> None:
        if not self._opp_editor_dirty or not self.current_opportunity_id:
            return

        payload = self.opp_form.get_payload()
        if not payload.get("title"):
            return
        if self._call_backend("Backend error", self.backend.update_opportunity, self.current_opportunity_id, **payload) is None:
            return

        self._opp_editor_dirty = False
        if refresh:
            self._refresh_opportunities(select_id=select_id or self.current_opportunity_id)

    def _export_opportunities_csv(self) -> None:
        if not self.current_project_id:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export opportunities CSV", "opportunities.csv", "CSV Files (*.csv)"
        )
        if not path:
            return

        rows = list(self._opp_cache.values())
        rows.sort(key=lambda o: (o.score, o.title), reverse=True)
        export_csv.export_opportunities(path, rows)

    def _refresh_opportunities(self, select_id: str | None = None) -> None:
        pid = self.current_project_id
        if not pid:
            return
        full = self._call_backend("Backend error", self.backend.list_opportunities, pid)
        if full is None:
            return

        filtered = self._apply_opportunity_filters(full)

        self._update_scored_filter_report(self.opp_filter_report, len(full), list(filtered))
        self._opp_title_by_id = {o.id: o.title for o in full}
        self._opp_cache = populate_scored_table(self.opps_table, list(filtered), mk_item=self._mk_item)

        self._select_row_by_entity_id(select_id, table=self.opps_table)
        self.opps_table.resizeColumnsToContents()

    def _apply_opportunity_filters(self, opps: list[Opportunity]) -> list[Opportunity]:
        mn, mx = score_bounds(self.opp_filter_min_score, self.opp_filter_max_score)

        dt_from, dt_to = date_bounds(self.opp_filter_from, self.opp_filter_to)
        criteria = filters.OpportunityFilterCriteria(
            search=(self.opp_filter_search.text() or ""),
            min_score=mn,
            max_score=mx,
            status=(self.opp_filter_status.currentText() or "(any)"),
            category_contains=(self.opp_filter_category.text() or ""),
            owner_contains=(self.opp_filter_owner.text() or ""),
            identified_from=dt_from,
            identified_to=dt_to,
        )
        return filters.filter_opportunities(opps, criteria)

    def _on_opportunity_clicked(self, row: int, col: int) -> None:
        t_it = self.opps_table.item(row, 1)
        if not t_it:
            return

        clicked_oid = t_it.data(Qt.UserRole)
        if not clicked_oid:
            return
        clicked_oid = str(clicked_oid)

        if self._opp_editor_dirty and self.current_opportunity_id and self.current_opportunity_id != clicked_oid:
            self._commit_opp_editor_changes(refresh=True, select_id=clicked_oid)
            row = self.opps_table.currentRow()
            col = self.opps_table.currentColumn() if self.opps_table.currentColumn() >= 0 else 0

        self.opps_table.setCurrentCell(row, col)

        o = self._opp_cache.get(clicked_oid)
        if not o:
            return

        self.current_opportunity_id = o.id
        self.opp_editor_label.setText(f"Editor (editing: {o.title})")
        self.opp_form.set_values(**form_values_for_entity(o))
        self._opp_editor_dirty = False

    def _start_new_opportunity(self) -> None:
        self.current_opportunity_id = None
        self.opp_editor_label.setText("Editor (new opportunity)")
        self.opp_form.set_values(title="", probability=3, impact=3)
        self._opp_editor_dirty = False
        self.opps_table.clearSelection()

    def _save_opportunity(self, payload: dict) -> None:
        pid = self.current_project_id
        if not pid:
            QMessageBox.warning(self, "No project", "Select a project first.")
            return

        data = dict(payload or {})
        title = (data.pop("title", "") or "").strip()
        p = int(data.pop("probability", 3) or 3)
        i = int(data.pop("impact", 3) or 3)

        norm_optional_text_fields(
            data,
            [
                "code", "description", "category", "threat", "triggers",
                "mitigation_plan", "document_url", "owner_user_id", "status",
                "identified_at", "status_changed_at", "response_at", "occurred_at",
            ],
        )

        if self.current_opportunity_id:
            oid = self.current_opportunity_id
            prev = self._opp_cache.get(oid)
            prev_status = (prev.status or "") if prev else ""
            new_status = (data.get("status") or "")
            if new_status and new_status != prev_status:
                data["status_changed_at"] = datetime.utcnow().isoformat()
            if self._call_backend("Backend error", self.backend.update_opportunity, oid, title=title, probability=p, impact=i, **data) is None:
                return

            self._opp_editor_dirty = False
            self._refresh_opportunities(select_id=oid)
            self.opp_editor_label.setText(f"Editor (editing: {title})")

        else:
            if not data.get("identified_at"):
                data["identified_at"] = datetime.utcnow().isoformat()
            o = self._call_backend("Backend error", self.backend.create_opportunity, pid, title=title, probability=p, impact=i, **data)
            if o is None:
                return
            self._opp_editor_dirty = False
            self._refresh_opportunities(select_id=o.id)
            self._start_new_opportunity()

        self._refresh_action_opp_combo()
        self._refresh_actions()