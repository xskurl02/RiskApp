# sqlite_store.py
from __future__ import annotations

import os
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Type, TypeVar

from riskapp_client.domain.models import Project, Risk, Opportunity, Action, Assessment
from riskapp_client.adapters.local.sqlite_schema import ensure_schema
from riskapp_client.domain.action_assessment_codec import action_from_mapping, assessment_from_mapping
from riskapp_client.domain.scored_codec import scored_entity_from_mapping
from riskapp_client.domain.scored_fields import (
    SCORED_ENTITY_DB_COLUMNS,
    SCORED_ENTITY_META_KEYS,
    SCORED_ENTITY_META_SQLITE_COLUMNS,
)

def utc_iso() -> str:
    return datetime.utcnow().isoformat()


def _norm_text(v: str | None) -> str | None:
    """Normalize optional text fields (strip; empty -> None)."""
    if v is None:
        return None
    s = str(v).strip()
    return s if s else None

ModelT = TypeVar("ModelT")

_TEXT_META_KEYS: set[str] = {
    name
    for name, col_type in SCORED_ENTITY_META_SQLITE_COLUMNS
    if str(col_type).upper().startswith("TEXT")
}
_INT_META_KEYS: set[str] = {
    name
    for name, col_type in SCORED_ENTITY_META_SQLITE_COLUMNS
    if str(col_type).upper().startswith("INTEGER")
}

_VALID_SCORED_TABLES: set[str] = {"risks", "opportunities"}


class LocalStore:
    def __init__(self, db_path: str) -> None:
        self.db_path = db_path

        existed = os.path.exists(db_path)
        db_dir = os.path.dirname(db_path)
        if db_dir:
            # Best-effort private directory (POSIX). On Windows this is a no-op.
            os.makedirs(db_dir, exist_ok=True)
            try:
                os.chmod(db_dir, 0o700)
            except OSError:
                pass

        # `timeout` helps avoid transient "database is locked" in WAL mode.
        self.conn = sqlite3.connect(self.db_path, timeout=5.0)
        self.conn.row_factory = sqlite3.Row

        # Best-effort private file permissions if we just created the DB.
        if not existed and os.path.exists(db_path):
            try:
                os.chmod(db_path, 0o600)
            except OSError:
                pass

        self._init_schema()

    def _init_schema(self) -> None:
        ensure_schema(self.conn)

    # --------- Projects ---------

    def upsert_projects(self, projects: List[Project]) -> None:
        cur = self.conn.cursor()
        for p in projects:
            cur.execute(
                """
                INSERT INTO projects (id, name, description)
                VALUES (?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                  name=excluded.name,
                  description=excluded.description
                """,
                (p.id, p.name, p.description or ""),
            )
        self.conn.commit()

    def list_actions(self, project_id: str) -> List[Action]:
        rows = self.conn.execute(
            """
            SELECT *
            FROM actions
            WHERE project_id=? AND is_deleted=0
            ORDER BY updated_at DESC, title ASC
            """,
            (project_id,),
        ).fetchall()
        return [action_from_mapping(r) for r in rows]
    
    def _pending_outbox_ids(self, project_id: str, *, entity: str) -> set[str]:
        rows = self.conn.execute(
            "SELECT entity_id FROM outbox WHERE project_id=? AND entity=? AND status='pending';",
            (project_id, entity),
        ).fetchall()
        return {str(r["entity_id"]) for r in rows}

    def _get_action_row(self, action_id: str) -> Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM actions WHERE id=?;", (action_id,)).fetchone()

    def get_action_project_and_version(self, action_id: str) -> Tuple[str, int]:
        r = self._get_action_row(action_id)
        if not r:
            raise KeyError("action not found in local store")
        return str(r["project_id"]), int(r["version"])

    def upsert_local_action(
        self,
        *,
        action_id: str,
        project_id: str,
        risk_id: str | None,
        opportunity_id: str | None,
        kind: str,
        title: str,
        description: str,
        status: str,
        owner_user_id: str | None,
        version: Optional[int] = None,
        is_deleted: Optional[bool] = None,
        updated_at: Optional[str] = None,
        dirty: int = 1,
    ) -> None:
        existing = self._get_action_row(action_id)
        cur = self.conn.cursor()
        cur.execute(
            """
            INSERT INTO actions (
            id, project_id, risk_id, opportunity_id, kind, title, description, status, owner_user_id,
            version, is_deleted, updated_at, dirty
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
            project_id=excluded.project_id,
            risk_id=excluded.risk_id,
            opportunity_id=excluded.opportunity_id,
            kind=excluded.kind,
            title=excluded.title,
            description=excluded.description,
            status=excluded.status,
            owner_user_id=excluded.owner_user_id,
            version=excluded.version,
            is_deleted=excluded.is_deleted,
            updated_at=excluded.updated_at,
            dirty=excluded.dirty
            """,
            (
                action_id,
                project_id,
                risk_id,
                opportunity_id,
                kind,
                title,
                description or "",
                status or "open",
                owner_user_id,
                int(version if version is not None else (existing["version"] if existing else 0)),
                int(is_deleted if is_deleted is not None else (existing["is_deleted"] if existing else 0)),
                str(updated_at if updated_at is not None else (existing["updated_at"] if existing else "")),
                int(dirty),
            ),
        )
        self.conn.commit()

    def apply_pull_actions(self, project_id: str, server_actions: List[Dict[str, Any]]) -> None:
        pending_ids = self._pending_outbox_ids(project_id, entity="action")
        cur = self.conn.cursor()
        for raw in server_actions:
            payload = dict(raw)
            payload.setdefault("project_id", project_id)
            action = action_from_mapping(payload)

            if action.id in pending_ids:
                cur.execute(
                    "UPDATE actions SET version=?, updated_at=? WHERE id=?;",
                    (int(action.version), str(action.updated_at or ""), str(action.id)),
                )
                continue

            cur.execute(
                """
                INSERT INTO actions (
                id, project_id, risk_id, opportunity_id, kind, title, description, status, owner_user_id,
                version, is_deleted, updated_at, dirty
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                ON CONFLICT(id) DO UPDATE SET
                project_id=excluded.project_id,
                risk_id=excluded.risk_id,
                opportunity_id=excluded.opportunity_id,
                kind=excluded.kind,
                title=excluded.title,
                description=excluded.description,
                status=excluded.status,
                owner_user_id=excluded.owner_user_id,
                version=excluded.version,
                is_deleted=excluded.is_deleted,
                updated_at=excluded.updated_at,
                dirty=0
                """,
                (
                    str(action.id),
                    project_id,
                    action.risk_id,
                    action.opportunity_id,
                    str(action.kind or ""),
                    str(action.title or ""),
                    str(action.description or ""),
                    str(action.status or "open"),
                    action.owner_user_id,
                    int(action.version),
                    1 if bool(action.is_deleted) else 0,
                    str(action.updated_at or ""),
                ),
            )

        self.conn.commit()

    def list_projects(self) -> List[Project]:
        rows = self.conn.execute("SELECT id, name, description FROM projects ORDER BY name;").fetchall()
        return [Project(id=r["id"], name=r["name"], description=r["description"]) for r in rows]

    def get_meta(self, key: str) -> Optional[str]:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?;", (key,)).fetchone()
        return str(row["value"]) if row else None

    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT INTO meta(key,value) VALUES (?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        self.conn.commit()
    

    def _next_code(self, project_id: str, *, table: str, prefix: str) -> str:
        """Best-effort local code generator (e.g. R-001 / O-001).

        This satisfies the "Označení" identifier requirement even in offline mode.
        The server remains the source of truth.
        """
        like = f"{prefix}-%"
        rows = self.conn.execute(
            f"SELECT code FROM {table} WHERE project_id=? AND code LIKE ? AND code IS NOT NULL;",
            (project_id, like),
        ).fetchall()

        max_n = 0
        for r in rows:
            c = _norm_text(r["code"])
            if not c:
                continue
            parts = c.split("-", 2)
            if len(parts) < 2:
                continue
            if parts[0].strip().upper() != prefix.upper():
                continue
            num_part = parts[1].strip()
            if num_part.isdigit():
                max_n = max(max_n, int(num_part))

        return f"{prefix}-{max_n + 1:03d}"

    def next_risk_code(self, project_id: str) -> str:
        return self._next_code(project_id, table="risks", prefix="R")

    def next_opportunity_code(self, project_id: str) -> str:
        return self._next_code(project_id, table="opportunities", prefix="O")

    # --------- Shared helpers for Risks/Opportunities (scored entities) ---------

    def _assert_scored_table(self, table: str) -> None:
        if table not in _VALID_SCORED_TABLES:
            raise ValueError(f"Invalid scored-entity table: {table!r}")

    def _list_scored_entities(self, project_id: str, *, table: str, model_cls: Type[ModelT]) -> List[ModelT]:
        self._assert_scored_table(table)
        cols = ", ".join(SCORED_ENTITY_DB_COLUMNS)
        rows = self.conn.execute(
            f"""
            SELECT {cols}
            FROM {table}
            WHERE project_id=? AND is_deleted=0
            ORDER BY (probability*impact) DESC, title ASC
            """,
            (project_id,),
        ).fetchall()
        return [scored_entity_from_mapping(r, model_cls=model_cls) for r in rows]

    def _get_scored_row(self, table: str, entity_id: str) -> Optional[sqlite3.Row]:
        self._assert_scored_table(table)
        return self.conn.execute(f"SELECT * FROM {table} WHERE id=?;", (entity_id,)).fetchone()

    def _get_scored_project_and_version(self, table: str, entity_id: str, *, label: str) -> Tuple[str, int]:
        row = self._get_scored_row(table, entity_id)
        if not row:
            raise KeyError(f"{label} not found in local store")
        return str(row["project_id"]), int(row["version"])

    def _norm_scored_meta(self, meta: Dict[str, Any]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for k in SCORED_ENTITY_META_KEYS:
            v = meta.get(k)
            if k in _TEXT_META_KEYS:
                out[k] = _norm_text(v) if v is not None else None
            elif k in _INT_META_KEYS:
                out[k] = int(v) if v is not None else None
            else:
                out[k] = v
        return out

    def _upsert_local_scored(
        self,
        *,
        table: str,
        entity_id: str,
        project_id: str,
        title: str,
        probability: int,
        impact: int,
        meta: Dict[str, Any],
        version: Optional[int],
        is_deleted: Optional[bool],
        updated_at: Optional[str],
        dirty: int,
    ) -> None:
        self._assert_scored_table(table)
        existing = self._get_scored_row(table, entity_id)

        v = int(version if version is not None else (existing["version"] if existing else 0))
        is_del = int(is_deleted if is_deleted is not None else (existing["is_deleted"] if existing else 0))
        upd = str(updated_at if updated_at is not None else (existing["updated_at"] if existing else ""))

        m = self._norm_scored_meta(meta)
        # Ensure a stable status value even if the server omitted it.
        if not m.get("status"):
            m["status"] = "concept"

        record: Dict[str, Any] = {
            "id": entity_id,
            "project_id": project_id,
            "title": str(title or ""),
            "probability": int(probability),
            "impact": int(impact),
            **m,
            "version": v,
            "is_deleted": is_del,
            "updated_at": upd,
            "dirty": int(dirty),
        }

        cols = list(SCORED_ENTITY_DB_COLUMNS) + ["dirty"]
        placeholders = ", ".join(["?"] * len(cols))
        col_list = ", ".join(cols)
        set_clause = ", ".join([f"{c}=excluded.{c}" for c in cols if c != "id"])

        self.conn.execute(
            f"""
            INSERT INTO {table} ({col_list})
            VALUES ({placeholders})
            ON CONFLICT(id) DO UPDATE SET
              {set_clause}
            """,
            tuple(record.get(c) for c in cols),
        )
        self.conn.commit()

    def _apply_pull_scored_entities(
        self,
        project_id: str,
        server_entities: List[Dict[str, Any]],
        *,
        table: str,
        outbox_entity: str,
    ) -> None:
        self._assert_scored_table(table)
        pending_ids = {
            r["entity_id"]
            for r in self.conn.execute(
                "SELECT entity_id FROM outbox WHERE project_id=? AND entity=? AND status='pending';",
                (project_id, outbox_entity),
            ).fetchall()
        }

        cols = list(SCORED_ENTITY_DB_COLUMNS) + ["dirty"]
        placeholders = ", ".join(["?"] * len(cols))
        col_list = ", ".join(cols)
        set_clause = ", ".join([f"{c}=excluded.{c}" for c in cols if c != "id"])

        sql_upsert = (
            f"INSERT INTO {table} ({col_list}) VALUES ({placeholders}) "
            f"ON CONFLICT(id) DO UPDATE SET {set_clause}"
        )

        cur = self.conn.cursor()
        for ent in server_entities:
            eid = str(ent["id"])
            ver = int(ent.get("version") or 0)
            upd = str(ent.get("updated_at") or "")

            if eid in pending_ids:
                cur.execute(
                    f"UPDATE {table} SET version=?, updated_at=? WHERE id=?;",
                    (ver, upd, eid),
                )
                continue

            meta = {k: ent.get(k) for k in SCORED_ENTITY_META_KEYS}
            if not meta.get("status"):
                meta["status"] = "concept"
            m = self._norm_scored_meta(meta)

            record: Dict[str, Any] = {
                "id": eid,
                "project_id": project_id,
                "title": str(ent.get("title") or ""),
                "probability": int(ent.get("probability") or 1),
                "impact": int(ent.get("impact") or 1),
                **m,
                "version": ver,
                "is_deleted": 1 if bool(ent.get("is_deleted")) else 0,
                "updated_at": upd,
                "dirty": 0,
            }
            cur.execute(sql_upsert, tuple(record.get(c) for c in cols))

        self.conn.commit()
    # --------- Risks ---------

    def list_risks(self, project_id: str) -> List[Risk]:
        return self._list_scored_entities(project_id, table="risks", model_cls=Risk)

    def _get_risk_row(self, risk_id: str) -> Optional[sqlite3.Row]:
        return self._get_scored_row("risks", risk_id)

    def get_risk_row(self, risk_id: str) -> sqlite3.Row | None:
        return self._get_risk_row(risk_id)

    def get_risk_project_and_version(self, risk_id: str) -> Tuple[str, int]:
        return self._get_scored_project_and_version("risks", risk_id, label="risk")

    def upsert_local_risk(
        self,
        *,
        risk_id: str,
        project_id: str,
        title: str,
        probability: int,
        impact: int,
        impact_cost: int | None = None,
        impact_time: int | None = None,
        impact_scope: int | None = None,
        impact_quality: int | None = None,
        code: str | None = None,
        description: str | None = None,
        category: str | None = None,
        threat: str | None = None,
        triggers: str | None = None,
        mitigation_plan: str | None = None,
        document_url: str | None = None,
        owner_user_id: str | None = None,
        status: str | None = None,
        identified_at: str | None = None,
        status_changed_at: str | None = None,
        response_at: str | None = None,
        occurred_at: str | None = None,
        version: Optional[int] = None,
        is_deleted: Optional[bool] = None,
        updated_at: Optional[str] = None,
        dirty: int = 1,
    ) -> None:
        meta: Dict[str, Any] = {
            "code": code,
            "description": description,
            "category": category,
            "threat": threat,
            "triggers": triggers,
            "mitigation_plan": mitigation_plan,
            "document_url": document_url,
            "owner_user_id": owner_user_id,
            "status": status,
            "identified_at": identified_at,
            "status_changed_at": status_changed_at,
            "response_at": response_at,
            "occurred_at": occurred_at,
            "impact_cost": impact_cost,
            "impact_time": impact_time,
            "impact_scope": impact_scope,
            "impact_quality": impact_quality,
        }

        self._upsert_local_scored(
            table="risks",
            entity_id=risk_id,
            project_id=project_id,
            title=title,
            probability=probability,
            impact=impact,
            meta=meta,
            version=version,
            is_deleted=is_deleted,
            updated_at=updated_at,
            dirty=dirty,
        )

    def mark_risk_clean(self, risk_id: str) -> None:
        self.conn.execute("UPDATE risks SET dirty=0 WHERE id=?;", (risk_id,))
        self.conn.commit()
    
    # --------- Opportunities ---------
    def list_opportunities(self, project_id: str) -> List[Opportunity]:
        return self._list_scored_entities(project_id, table="opportunities", model_cls=Opportunity)

    def _get_opportunity_row(self, opportunity_id: str) -> Optional[sqlite3.Row]:
        return self._get_scored_row("opportunities", opportunity_id)
    
    def get_opportunity_row(self, opportunity_id: str) -> sqlite3.Row | None:
        return self._get_opportunity_row(opportunity_id)

    def get_opportunity_project_and_version(self, opportunity_id: str) -> Tuple[str, int]:
        return self._get_scored_project_and_version("opportunities", opportunity_id, label="opportunity")

    def upsert_local_opportunity(
        self,
        *,
        opportunity_id: str,
        project_id: str,
        title: str,
        probability: int,
        impact: int,
        impact_cost: int | None = None,
        impact_time: int | None = None,
        impact_scope: int | None = None,
        impact_quality: int | None = None,
        code: str | None = None,
        description: str | None = None,
        category: str | None = None,
        threat: str | None = None,
        triggers: str | None = None,
        mitigation_plan: str | None = None,
        document_url: str | None = None,
        owner_user_id: str | None = None,
        status: str | None = None,
        identified_at: str | None = None,
        status_changed_at: str | None = None,
        response_at: str | None = None,
        occurred_at: str | None = None,
        version: Optional[int] = None,
        is_deleted: Optional[bool] = None,
        updated_at: Optional[str] = None,
        dirty: int = 1,
    ) -> None:
        meta: Dict[str, Any] = {
            "code": code,
            "description": description,
            "category": category,
            "threat": threat,
            "triggers": triggers,
            "mitigation_plan": mitigation_plan,
            "document_url": document_url,
            "owner_user_id": owner_user_id,
            "status": status,
            "identified_at": identified_at,
            "status_changed_at": status_changed_at,
            "response_at": response_at,
            "occurred_at": occurred_at,
            "impact_cost": impact_cost,
            "impact_time": impact_time,
            "impact_scope": impact_scope,
            "impact_quality": impact_quality,
        }

        self._upsert_local_scored(
            table="opportunities",
            entity_id=opportunity_id,
            project_id=project_id,
            title=title,
            probability=probability,
            impact=impact,
            meta=meta,
            version=version,
            is_deleted=is_deleted,
            updated_at=updated_at,
            dirty=dirty,
        )

    def list_assessments(self, project_id: str, risk_id: str) -> List[Assessment]:
        rows = self.conn.execute(
            """
            SELECT * FROM assessments
            WHERE project_id=? AND risk_id=? AND is_deleted=0
            ORDER BY updated_at DESC
            """,
            (project_id, risk_id),
        ).fetchall()
        return [assessment_from_mapping(r) for r in rows]

    def get_assessment_project_and_version(self, assessment_id: str) -> Tuple[str, int]:
        row = self.conn.execute(
            "SELECT project_id, version FROM assessments WHERE id=?;",
            (assessment_id,),
        ).fetchone()
        if not row:
            raise ValueError("assessment not found")
        return (str(row["project_id"]), int(row["version"]))

    def upsert_local_assessment(
        self,
        *,
        assessment_id: str,
        project_id: str,
        risk_id: str,
        assessor_user_id: str,
        probability: int,
        impact: int,
        notes: Optional[str],
        version: int,
        is_deleted: bool,
        updated_at: str,
        dirty: int,
    ) -> None:
        score = int(probability) * int(impact)
        self.conn.execute(
            """
            INSERT INTO assessments (id, project_id, risk_id, assessor_user_id, probability, impact, score, notes,
                                    version, is_deleted, updated_at, dirty)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
            project_id=excluded.project_id,
            risk_id=excluded.risk_id,
            assessor_user_id=excluded.assessor_user_id,
            probability=excluded.probability,
            impact=excluded.impact,
            score=excluded.score,
            notes=excluded.notes,
            version=excluded.version,
            is_deleted=excluded.is_deleted,
            updated_at=excluded.updated_at,
            dirty=excluded.dirty
            """,
            (assessment_id, project_id, risk_id, assessor_user_id, int(probability), int(impact), score, notes,
            int(version), 1 if is_deleted else 0, updated_at, int(dirty)),
        )
        self.conn.commit()

    # --------- Sync state ---------

    def get_last_server_time(self, project_id: str) -> str:
        row = self.conn.execute("SELECT last_server_time FROM sync_state WHERE project_id=?;", (project_id,)).fetchone()
        return str(row["last_server_time"]) if row else "1970-01-01T00:00:00"

    def set_last_server_time(self, project_id: str, server_time: str) -> None:
        self.conn.execute(
            """
            INSERT INTO sync_state(project_id, last_server_time)
            VALUES (?, ?)
            ON CONFLICT(project_id) DO UPDATE SET last_server_time=excluded.last_server_time
            """,
            (project_id, server_time),
        )
        self.conn.commit()

    # --------- Apply pull ---------

    def apply_pull_risks(self, project_id: str, server_risks: List[Dict[str, Any]]) -> None:
        self._apply_pull_scored_entities(
            project_id,
            server_risks,
            table="risks",
            outbox_entity="risk",
        )

    def apply_pull_opportunities(self, project_id: str, server_opps: List[Dict[str, Any]]) -> None:
        self._apply_pull_scored_entities(
            project_id,
            server_opps,
            table="opportunities",
            outbox_entity="opportunity",
        )

    def apply_pull_assessments(self, project_id: str, server_assessments: List[Dict[str, Any]]) -> None:
        pending_ids = self._pending_outbox_ids(project_id, entity="assessment")
 
        cur = self.conn.cursor()
        for raw in server_assessments:
            assessment = assessment_from_mapping(raw)
            score = int(assessment.score)
            is_del = 1 if bool(assessment.is_deleted) else 0
            upd = str(assessment.updated_at or "")
            ver = int(assessment.version)
            if assessment.id in pending_ids:
                cur.execute(
                    "UPDATE assessments SET version=?, updated_at=? WHERE id=?;",
                    (ver, upd, str(assessment.id)),
                )
                continue

            cur.execute(
                """
                INSERT INTO assessments (id, project_id, risk_id, assessor_user_id, probability, impact, score, notes,
                                        version, is_deleted, updated_at, dirty)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                ON CONFLICT(id) DO UPDATE SET
                project_id=excluded.project_id,
                risk_id=excluded.risk_id,
                assessor_user_id=excluded.assessor_user_id,
                probability=excluded.probability,
                impact=excluded.impact,
                score=excluded.score,
                notes=excluded.notes,
                version=excluded.version,
                is_deleted=excluded.is_deleted,
                updated_at=excluded.updated_at,
                dirty=0
                """,
                (
                    str(assessment.id),
                    project_id,
                    str(assessment.risk_id),
                    str(assessment.assessor_user_id or ""),
                    int(assessment.probability),
                    int(assessment.impact),
                    score,
                    str(assessment.notes or ""),
                    ver,
                    is_del,
                    upd,
                ),
            )

        self.conn.commit()

