"""Local (SQLite) adapters."""
