"""Adapter layer package."""
