"""RiskApp Qt client package."""
